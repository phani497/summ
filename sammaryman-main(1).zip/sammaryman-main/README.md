# Text Summarization with a WordCloud

## Built with

1. Streamlit 
2. Wordcloud

## To run

```bash
   git clone https://github.com/Boadzie/sammaryman.git
```

```bash
   # in a virtualenv install the packages using ..
   pip install -r requirements.txt
```

```bash
  streamlit run app.py
```
